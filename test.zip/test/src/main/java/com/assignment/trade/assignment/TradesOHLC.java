package com.assignment.trade.assignment;


public class TradesOHLC {
	String sym;
	String T;
	Double P; 
	Double Q; 
	String Side;
	Double TS;
	Double TS2;
	
	public TradesOHLC() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TradesOHLC(String sym, String t, Double p, Double q, String side, Double tS, Double tS2) {
		super();
		this.sym = sym;
		T = t;
		P = p;
		Q = q;
		Side = side;
		TS = tS;
		TS2 = tS2;
	}

	@Override
	public String toString() {
		return "TradesOHLC [sym=" + sym + ", T=" + T + ", P=" + P + ", Q=" + Q + ", Side=" + Side + ", TS=" + TS
				+ ", TS2=" + TS2 + "]";
	}

	public String getSym() {
		return sym;
	}

	public void setSym(String sym) {
		this.sym = sym;
	}

	public String getT() {
		return T;
	}

	public void setT(String t) {
		T = t;
	}

	public Double getP() {
		return P;
	}

	public void setP(Double p) {
		P = p;
	}

	public Double getQ() {
		return Q;
	}

	public void setQ(Double q) {
		Q = q;
	}

	public String getSide() {
		return Side;
	}

	public void setSide(String side) {
		Side = side;
	}

	public Double getTS() {
		return TS;
	}

	public void setTS(Double tS) {
		TS = tS;
	}

	public Double getTS2() {
		return TS2;
	}

	public void setTS2(Double tS2) {
		TS2 = tS2;
	}

	

	
	
}
