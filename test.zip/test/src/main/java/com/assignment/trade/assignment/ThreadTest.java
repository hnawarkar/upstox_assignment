package com.assignment.trade.assignment;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class ThreadTest {
	   public static void main(String[] args) {
		  TradesJsonParser tradesJsonParser = new TradesJsonParser();
		  tradesJsonParser.setSubscription(args[0]);
	      Producer p1 = new Producer(tradesJsonParser);
	      Consumer c1 = new Consumer(tradesJsonParser);
	      EmptyBar e1= new EmptyBar(tradesJsonParser);
	      ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(4);
	      int initialDelay = 5;
	      int periodicDelay = 45;
	      scheduler.scheduleWithFixedDelay(p1, initialDelay, periodicDelay, TimeUnit.SECONDS);
	      scheduler.scheduleWithFixedDelay(c1, initialDelay,periodicDelay, TimeUnit.SECONDS);
	      	initialDelay = initialDelay+15;
	      	scheduler.scheduleWithFixedDelay(e1, initialDelay, periodicDelay, TimeUnit.SECONDS);
//	      	initialDelay = initialDelay+15;
	        scheduler.scheduleWithFixedDelay(e1, initialDelay, periodicDelay, TimeUnit.SECONDS);
//	      p1.start(); 
//	      c1.start();
	   }
	}

class TradesJsonParser{
	JSONObject jo;
	String subscription="";
	int cnt=1;
	 double sum=0.0;
	 double high=0.0;
	public double getSum() {
		return sum;
	}
	public void setSum(double sum) {
		this.sum = sum;
	}
	public double getHigh() {
		return high;
	}
	public void setHigh(double high) {
		this.high = high;
	}
	private boolean available = false;
	
	
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public String getSubscription() {
		return subscription;
	}
	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}

	 public synchronized JSONObject get() {
	      while (available == false) {
	         try {
	            wait();
	         } catch (InterruptedException e) {}
	      }
	      available = false;
	      notifyAll();
	      return jo;
	   }
	   public synchronized void put(JSONObject jo_val) {
	      while (available == true) {
	         try {
	            wait();
	         } catch (InterruptedException e) { } 
	      }
	      jo = jo_val;
	      available = true;
	      notifyAll();
	   }
	
}


class Producer extends Thread {
	   private TradesJsonParser tradesJsonParser;
	   private JSONObject jo;
	   public Producer(TradesJsonParser l_tradesJsonParser) {
		  tradesJsonParser = l_tradesJsonParser;
	   } 
	   public void run() {
		   
	        JSONParser jsonParser = new JSONParser();
	         
	        try (FileReader reader = new FileReader("data\\trades.json"))
	        {
	        
	      	    Scanner sc = new Scanner(reader); 
	   	  	    while (sc.hasNextLine()) { 
	                //Read JSON file
	                Object obj = jsonParser.parse(sc.nextLine());
	                jo = (JSONObject) obj;
	                if(tradesJsonParser.getSubscription().equals((String)jo.get("sym")))
	                 tradesJsonParser.put(jo);
	                
	                try {
	    	            sleep(1500);
	    	         } catch (InterruptedException e) { }
	                

	   	  	    }
	      } catch (FileNotFoundException e) {
	            e.printStackTrace();
	      } catch (IOException e) {
	            e.printStackTrace();
	      } catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
		  }
	   }
	} 


class Consumer extends Thread {
	 private TradesJsonParser tradesJsonParser;
	 private JSONObject jo;

	 public Consumer(TradesJsonParser l_tradesJsonParser) {
		  tradesJsonParser = l_tradesJsonParser;
	   } 
	   public void run() {
		   while(true) {
			   jo = tradesJsonParser.get();
	           TradesOHLC tradesOHLC =new TradesOHLC();
	           tradesOHLC.setP(Double.valueOf(jo.get("P").toString()));
	           tradesOHLC.setQ(Double.valueOf(jo.get("Q").toString()));
	           tradesOHLC.setSide((String)jo.get("side"));
	           tradesOHLC.setSym((String)jo.get("sym"));
	           tradesOHLC.setT((String)jo.get("T"));
	           tradesOHLC.setTS(Double.valueOf(jo.get("TS").toString()));
	           tradesOHLC.setTS2(Double.valueOf(jo.get("TS2").toString()));

	           Map m = new LinkedHashMap(); 
	           
	           tradesJsonParser.setSum(tradesJsonParser.getSum()+tradesOHLC.getQ());
	           if(tradesJsonParser.getHigh()<tradesOHLC.getP()) {
	        	   tradesJsonParser.setHigh(tradesOHLC.getP());
	           }
	           m.put("o", tradesJsonParser.getHigh());
	           m.put("h", tradesJsonParser.getHigh());
	           
	           m.put("l", tradesOHLC.getP());
	           m.put("c", 0);
	           m.put("volume",tradesJsonParser.getSum());
	           m.put("event", "ohlc_notify");
	           m.put("symbol", tradesOHLC.getSym());
	           m.put("bar_num", tradesJsonParser.getCnt());
	           JSONObject jo_out = new JSONObject(m);
	           System.out.println(jo_out.toJSONString(m));
		  }
	   }
	}


class EmptyBar extends Thread {
	 private TradesJsonParser tradesJsonParser;
	 public EmptyBar(TradesJsonParser l_tradesJsonParser) {
		  tradesJsonParser = l_tradesJsonParser;
	 } 
	public void run() {
		int count=tradesJsonParser.getCnt();
		count=count+1;
		tradesJsonParser.setCnt(count);
		tradesJsonParser.setSum(0.0);
		tradesJsonParser.setHigh(0.0);
		Map m = new LinkedHashMap(); 
		m.put("event", "ohlc_notify");
        m.put("symbol", tradesJsonParser.getSubscription());
        m.put("bar_num",count);
        JSONObject jo_out = new JSONObject(m);
        System.out.println(jo_out.toJSONString(m));
	}
	
}





	
