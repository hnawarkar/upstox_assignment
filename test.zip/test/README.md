# An example Java 8 project using Maven and JUnit 5.x

1. Get adoptopenjdk-8: https://adoptopenjdk.net/
2. Get maven 3.6.x: https://maven.apache.org/
3. Add above to your path if neccessary.
4. `git clone git@github.com:example/test.git`
5. `mvn clean package`
6. `java -jar target/test-1.0.0-SNAPSHOT.jar`
